# CSS Animation Challenge
This exercise focusses on the main basic principles of CSS Animations. I'll try to master them during this project. You can find the result [here](https://elisek-bc.github.io/css-animations/).

## Contributors
I, Elise, am the only contributor to this project.

## Timing
This exercise is a part of my 7-month educational training at BeCode. I started this on Wednesday 31 July 2019. It's a voluntary exercise, so I've set my own deadline on 5PM tonight. I made it in time, woohoow!

## Tools
- HTML
- CSS
FYI I'm working with Visual Studio Code as IDE.
